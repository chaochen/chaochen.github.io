mex -O mexPersistence.cpp persistence.cpp CubicalComplex.cpp utils.cpp debugger.cpp

