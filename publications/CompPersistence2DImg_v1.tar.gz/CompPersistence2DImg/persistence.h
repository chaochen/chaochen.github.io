#ifndef PERSISTENCE_H
#define PERSISTENCE_H

#include "utils.h"
#include "debugger.h"
#include "CubicalComplex.h"

#define MAX_PERS_PTS 1000	//maximum of numbers of persistence dots

//-----------------------------------------------------
//vertex-edge pair and persistence
//edge-trig pair and persistence
//-----------------------------------------------------
class VertEdgePair{
  public:
  int vbVertIdx;
  int edVertIdx;
  float pers_val;

  //initialize coordinates using the input vertices and persistence
  VertEdgePair(int , int , float );
  
  bool operator<(const VertEdgePair &rhs) const;
};

class EdgeFacePair{
  public:
  int ebVertIdx, fdVertIdx;
  float pers_val;
  
  //initialize coordinates using the input vertices and persistence
  EdgeFacePair( int , int , float ) ; 

  bool operator<(const EdgeFacePair &rhs) const;
};


class Persistence{
	public: 
	vector< Vertex > * vList;
	vector< Edge > * eList;
	vector< Face > * fList;

	myDoubleMatrix * phi;

	vector< VertEdgePair > * vePersList;
	vector< EdgeFacePair > * efPersList;
	int persPairSize;

	public:

	Persistence( myDoubleMatrix * p ) : phi(p), persPairSize(3) {
		vList=new vector< Vertex >;
		eList=new vector< Edge >;
		fList=new vector< Face >;
		vePersList=new vector< VertEdgePair >;
		efPersList=new vector< EdgeFacePair >;
	};

	~Persistence(){
		delete vList;
		delete eList;
		delete fList;
		delete vePersList;
		delete efPersList;
	};

	void calcPers(const int, const int, const double, int, long double *);

	int getPersPairSize(){ return persPairSize; };

	int getVELSize(){ return vePersList->size(); };

	void outputVEL(double *);

	int getEFLSize(){ return efPersList->size(); };

	void outputEFL(double *);

};


#endif
