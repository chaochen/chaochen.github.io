#ifndef CUBICALCOMPLEX_H
#define CUBICALCOMPLEX_H

#include "utils.h"
#include "debugger.h"


class Vertex{
	public:
	int xidx;
	int yidx;
	int mapXCoord;
	int mapYCoord;
	double val;
	Vertex(int ,int , double );	
	Vertex();
  	bool operator<(const Vertex &rhs) const;
};

class Edge{
	public:
	int v1_order;
	int v2_order;
	int mapXCoord;
	int mapYCoord;
	Edge(int ,int , int , int );	
	Edge(); 
  	bool operator<(const Edge &rhs) const;
};

class Face{
	public:
	int v1_order;
	int v2_order;
	int v3_order;
	int v4_order;
	int e1_order;
	int e2_order;
	int e3_order;
	int e4_order;
	int mapXCoord;
	int mapYCoord;
	Face(int ,int ,int ,int ,int ,int ,int ,int ,int ,int );
	Face(); 
  	bool operator<(const Face &rhs) const;
};

// bool vCompVal(Vertex , Vertex );

// bool eComp(Edge , Edge ); 

// bool fComp(Face , Face ); 

enum CellTypeEnum {CT_UNDEFINED, VERTEX, EDGEVERT, EDGEHORI, FACE};
enum EdgePersTypeEnum {EP_UNDEFINED, DESTROYER, CREATOR};
class CellMap{
public:
	int vertNum,edgeNum,faceNum;
	int mapNRow, mapNCol;
	int currEOrder, currTOrder;
	vector< vector < int > > cellOrder;
	vector< vector < CellTypeEnum > > cellType;
	
	vector< vector < EdgePersTypeEnum > > edgePersType;
	
	vector< Vertex > * vList;
	vector< Edge > * eList;
	vector< Face > * fList;

	void setVertOrder(int , int , int );

	CellMap(vector< Vertex > * , vector< Edge > * , vector< Face > * , int , int );
	
	void buildBoundary2D(vector<vector < int > > * );
					
	void buildBoundary1D(vector<vector < int > > * );

	void setEPersType( vector< int > * );

};	// end of class CellMap

#endif
