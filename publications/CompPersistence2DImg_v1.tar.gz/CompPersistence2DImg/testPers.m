%I=double(rgb2gray(imread('data/AbandonedBikes_StevenVance.jpeg')));  
%I=double(rgb2gray(imread('data/CosmicAssembly_Nasa.jpeg'))); 
I=double(rgb2gray(imread('data/Serbian_Whl_Travel.jpeg')));
%I=double(rgb2gray(imread('data/StreetPhotographer_zackojones.jpeg')));

persistence_thd=30;
max_p=6;
close all;

G=fspecial('gaussian',15,1);
for( i = 1:5 )
	I = imfilter(I,G,'symmetric','conv');
end;

%only compute total persistence
compute_extrema = 0;
[total_persistence]=mexPersistence(I,persistence_thd,max_p,compute_extrema);
total_persistence

%compute total persistence, and extrema with big persistence
compute_extrema = 1;
[total_persistence,minima_list,maxima_list]=mexPersistence(I,persistence_thd,max_p,compute_extrema);

figure,imshow(I, []); hold on;
for(i=1:size(minima_list,2)) 
       plot(minima_list(2,i),minima_list(1,i),'yo','LineWidth',2,'MarkerFaceColor','y'); 
	% yellow markers -- minima with persistence >= 30
end;

for(i=1:size(maxima_list,2)) 
       plot(maxima_list(2,i),maxima_list(1,i),'ro','LineWidth',2,'MarkerFaceColor','r'); 
        % red markers -- maxima with persistence >= 30
end;

figure, hist(minima_list(3,:),100);
% draw histogram of persistence of minima

figure, hist(maxima_list(3,:),100);
% draw histogram of persistence of maxima
