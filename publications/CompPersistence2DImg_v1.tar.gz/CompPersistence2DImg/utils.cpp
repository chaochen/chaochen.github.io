#include "utils.h"

using namespace std;

myDoubleMatrix::myDoubleMatrix(int m,int n,double v) { 
	  nrow=m;
	  ncol=n;
	  int i,j;
	  for (i=0;i<nrow;i++)
		  data.push_back(vector< double >(ncol,v));
	  return;
  };

double myDoubleMatrix::get(int r, int c) { 
	 	MY_ASSERT(((0<=r)&&(r<nrow)), "%s\n", "ERROR");
	 	MY_ASSERT(((0<=c)&&(c<ncol)), "%s\n", "ERROR");
	     return data[r][c];
  };

void myDoubleMatrix::put(int r, int c, double v) { 
	 	MY_ASSERT((0<=r)&&(r<nrow), "%s\n", "ERROR");
	 	MY_ASSERT((0<=c)&&(c<ncol), "%s\n", "ERROR");
	        data[r][c]=v;
  };

void myDoubleMatrix::input1D(double *ptr){
	  int i,j;
	  for (i=0;i<nrow;i++)
		  for (j=0;j<ncol;j++)
			  data[i][j]=ptr[j*nrow+i];
  };

void myDoubleMatrix::output1D(double *ptr){
	  int i,j;
	  for (i=0;i<nrow;i++)
		  for (j=0;j<ncol;j++)
			  ptr[j*nrow+i]=data[i][j];
  };

// Mod-2 addition of two binary vectors (stored as two vectors of nonzero indices)
// We avoid excessive allocations by calculating the size of the resulting list.
// Then we resize the result and populate it with the actual values.
vector< int > vec_sym_diff(vector< int > &sa, vector< int > &sb){
	//assume inputs are both sorted increasingly	
	size_t count = 0;
	Counter< vector< int > > counter(count);
	set_symmetric_difference(sa.begin(), sa.end(), sb.begin(), sb.end(), counter);
	vector< int > out;	
	
	out.reserve(count);
	set_symmetric_difference(sa.begin(), sa.end(), sb.begin(), sb.end(), back_inserter(out));	

	return out;
}

// list<int> list_sym_diff(list<int> sa ,list<int> sb ){
// 	//assume inputs are both sorted increasingly
// 	
// 	sa.push_back(BIG_INT);
// 	sb.push_back(BIG_INT);
// 	list<int> sc;
// 
// 	list<int>::iterator ia=sa.begin();
// 	list<int>::iterator ib=sb.begin();
// 
// 	while(!((* ia==BIG_INT)&&(* ib==BIG_INT))){
// 		if (*ia < *ib){
// 		       sc.push_back(* ia);
// 		       ia++;
// 		}else if(*ia > *ib){ 
// 			sc.push_back(* ib);
// 			ib++;
// 		}else if(*ia != BIG_INT){
// 			ia ++;
// 			ib ++;
// 		}
// 	};
// 	return sc;
// }


// #######################################################
// To be handled. global elements.

