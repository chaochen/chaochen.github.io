#include "persistence.h"

VertEdgePair::VertEdgePair(int vbi, int edi, float per) : 
  vbVertIdx(vbi),edVertIdx(edi),
  pers_val(per){};
  
bool VertEdgePair::operator<(const VertEdgePair &rhs) const{
    return (this->pers_val >= rhs.pers_val);
  };

EdgeFacePair::EdgeFacePair( int ebi, int fdi, float per) : 
  ebVertIdx(ebi),fdVertIdx(fdi),
  pers_val(per){};

bool EdgeFacePair::operator<(const EdgeFacePair &rhs) const{
    return (this->pers_val >= rhs.pers_val);
  };

void Persistence::calcPers(const int m,const int n, const double pers_thd, int maxdegree, long double * degreep){
  
	OUTPUT_MSG("Begin computing persistence");

	//constructing vList
	int i,j;
	
	for(i=0;i<maxdegree;i++) degreep[i]=0;
	
	double tmp_pers;
	
	for (i=0;i<m;i++)
		for (j=0;j<n;j++)
			vList->push_back(Vertex(i,j,phi->data[i][j]));
 
	//sort vList
	sort(vList->begin(), vList->end());

	OUTPUT_MSG("--vList constructed and sorted");

	CellMap myCM(vList,eList,fList, phi->nrow, phi->ncol);

	//construct and reduce 2d boundary matrix
	vector< vector< int > > * boundary_2D=new vector< vector< int > >(myCM.faceNum, vector< int >()); //first index is col index, each col init to empty
	myCM.buildBoundary2D(boundary_2D);
	vector< int > * low_2D_e2t=new vector< int >(myCM.edgeNum,-1);

	multiset< EdgeFacePair > etQueue;	// persistence pairs

	int num_e_creator=0;
	int num_t_destroyer=0;
	int num_v_creator=0;// number of vertices creating non-essential class
	int num_e_destroyer=0;// number of edge destroyer (non-essential)

	//output edge-face pairs whose persistence is bigger than pers_thd
	int vBirth,vDeath;
	int tmp_int;
	double tmp_death,tmp_birth;
	
	int low;

	list<int>::iterator myiter;
	int tmpe12,tmpe23,tmpe13;
	map<int, int>::iterator tmpit;
	for (i=0;i<myCM.faceNum;i++){

		//reduce column i
		low = * (* boundary_2D)[i].rbegin();

		while ( ( ! (* boundary_2D)[i].empty() ) && ( (* low_2D_e2t)[low]!=-1 ) ){
			(* boundary_2D)[i]=vec_sym_diff((* boundary_2D)[i],(* boundary_2D)[(* low_2D_e2t)[low]]);

			if(! (* boundary_2D)[i].empty()){
				low = * (* boundary_2D)[i].rbegin();
			}
		}
		if (! (* boundary_2D)[i].empty()){

			MY_ASSERT((low>=0), "%s\n", "ERROR");
			MY_ASSERT(((* low_2D_e2t)[low]==-1), "%s\n", "ERROR");
			(* low_2D_e2t)[low]=i;
			num_t_destroyer++;
			num_e_creator++;

			//record pair
			Edge edgeCreator=(* eList)[low];
			Face faceDestroyer=(* fList)[i];
			vBirth= edgeCreator.v2_order;
			vDeath= faceDestroyer.v4_order;
			tmp_death=phi->data[(* vList)[vDeath].xidx][(* vList)[vDeath].yidx];
			tmp_birth=phi->data[(* vList)[vBirth].xidx][(* vList)[vBirth].yidx];

			tmp_pers=max(0.0,tmp_death-tmp_birth);
			    for(int p=0;p<maxdegree;p++)
				degreep[p]=degreep[p]+max(0.0,pow(tmp_pers,double(p+1)));


			if(tmp_pers>pers_thd){
			    //recording pers pairs
			    efPersList->push_back(EdgeFacePair(vBirth, vDeath, tmp_pers));

			}
		}else{
			MY_ASSERT((false), "%s\n", "ERROR");
		}


		if (i % 100000 == 0)
		  OUTPUT_MSG( "reducing boundary 2D: i=" << i <<", face number=" << myCM.faceNum );
	}
	
	myCM.setEPersType( low_2D_e2t );

	set < int > bigt;
	int hole_creator;
	int hole_ct = 0;
	int new_holes_created=0;

	vector<bool> big_holes(myCM.faceNum,false);

	delete boundary_2D;

	OUTPUT_MSG( "boundary_2D all reduced" );

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//construct and reduce 1d boundary matrix

	vector< int > * low_1D_v2e= new vector< int >(myCM.vertNum,-1);
	// for each creator vertex, store the edge it is paired to
	
	vector< vector< int > > * boundary_1D=new vector< vector< int > >(myCM.edgeNum, vector< int >()); //first index is col index, each col init to empty
	myCM.buildBoundary1D(boundary_1D);

	multiset< VertEdgePair > veQueue;	// persistence pairs

	int tmptmp=0;
	int tmptmptmp=0;

	for (i=0;i<myCM.edgeNum;i++){

		if ( (* low_2D_e2t)[i] >= 0 ){ 
			(*boundary_1D)[i].clear();
			tmptmp++;
		  continue;
		}else{
			tmptmptmp++;
		  MY_ASSERT(((* low_2D_e2t)[i] == -1), "%s\n", "ERROR");
		  MY_ASSERT(((*boundary_1D)[i].size()==2), "%s\n", "ERROR");
		};
	  
		//reduce column i
		low = * (* boundary_1D)[i].rbegin();

		while ( ( ! (* boundary_1D)[i].empty() ) && ( (* low_1D_v2e)[low]!=-1 ) ){
			(* boundary_1D)[i]=vec_sym_diff((* boundary_1D)[i],(* boundary_1D)[(* low_1D_v2e)[low]]);
			if(! (* boundary_1D)[i].empty()){
				low = * (* boundary_1D)[i].rbegin();
			}
		}
		if (! (* boundary_1D)[i].empty()){
			MY_ASSERT((low>=0), "%s\n", "ERROR");
			MY_ASSERT(((* low_1D_v2e)[low]==-1), "%s\n", "ERROR");
			(* low_1D_v2e)[low]=i;
			num_e_destroyer++;
			num_v_creator++;

			MY_ASSERT(((* boundary_1D)[i].size()==2), "%s\n", "ERROR");
			
			int high =  * (* boundary_1D)[i].begin();
			//reduce high
			while (  (* low_1D_v2e)[high]!=-1 ){
				int edge_high=(*low_1D_v2e)[high];
				(* boundary_1D)[i]=vec_sym_diff((* boundary_1D)[i],(* boundary_1D)[edge_high]);
				MY_ASSERT(((* boundary_1D)[i].size()==2), "%s\n", "ERROR");
				high = * (* boundary_1D)[i].begin();
			}

			//record pair
			vBirth= low;	//creator vertex
			Edge eDestroyer = (* eList)[i];
			vDeath=eDestroyer.v2_order;
			tmp_death=phi->data[(* vList)[vDeath].xidx][(* vList)[vDeath].yidx];
			tmp_birth=phi->data[(* vList)[vBirth].xidx][(* vList)[vBirth].yidx];
			
			tmp_pers=max(0.0,tmp_death-tmp_birth);
			    for(int p=0;p<maxdegree;p++)
				degreep[p]=degreep[p]+pow(tmp_pers,double(p+1));


			if(tmp_pers>pers_thd){
			    //recording pers pairs
			    vePersList->push_back(VertEdgePair(vBirth, vDeath, tmp_pers));

			}


		}else{
			MY_ASSERT((false), "%s\n", "ERROR");
		}

		if (i % 100000 == 0)
		  OUTPUT_MSG( "reducing boundary 1D: i=" << i <<", edge number=" << myCM.edgeNum );
	}
	MY_ASSERT((num_v_creator==myCM.vertNum-1), "%s\n", "ERROR");
	MY_ASSERT((num_e_destroyer==num_v_creator), "%s\n", "ERROR");
// 	MY_ASSERT((num_e_creator+num_e_destroyer==myCM.edgeNum), "%s\n", "ERROR");
// 	MY_ASSERT((num_t_destroyer==myCM.faceNum), "%s\n", "ERROR");
	OUTPUT_MSG( "boundary 1D all reduced" );

	
	delete low_1D_v2e;
	delete low_2D_e2t;
	delete boundary_1D;

	sort(vePersList->begin(),vePersList->end());
	sort(efPersList->begin(),efPersList->end());
};

void Persistence::outputVEL(double *ptr){
	  int ncol = vePersList->size();
	  int nrow = persPairSize;

	  int i,j;

	  for (j=0;j<ncol;j++){
		ptr[ j*nrow+0 ] = (double) (* vList)[(* vePersList)[j].vbVertIdx].xidx+1;
		ptr[ j*nrow+1 ] = (double) (* vList)[(* vePersList)[j].vbVertIdx].yidx+1;
//		ptr[ j*nrow+2 ] = (double) (* vList)[(* vePersList)[j].edVertIdx].xidx+1;
//		ptr[ j*nrow+3 ] = (double) (* vList)[(* vePersList)[j].edVertIdx].yidx+1;
		ptr[ j*nrow+2 ] = (double) (* vePersList)[j].pers_val;
	  };

	  return;
};

void Persistence::outputEFL(double *ptr){
	  int ncol = efPersList->size();
	  int nrow = persPairSize;

	  int i,j;

	  for (j=0;j<ncol;j++){
//		ptr[ j*nrow+0 ] = (double) (* vList)[(* efPersList)[j].ebVertIdx].xidx+1;
//		ptr[ j*nrow+1 ] = (double) (* vList)[(* efPersList)[j].ebVertIdx].yidx+1;
		ptr[ j*nrow+0 ] = (double) (* vList)[(* efPersList)[j].fdVertIdx].xidx+1;
		ptr[ j*nrow+1 ] = (double) (* vList)[(* efPersList)[j].fdVertIdx].yidx+1;
		ptr[ j*nrow+2 ] = (double) (* efPersList)[j].pers_val;
	  };

	  return;
};

