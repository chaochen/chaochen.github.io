#include "utils.h"

using namespace std;

void RandGenerator::init(){ srand((unsigned)time(0)); };

int RandGenerator::randIdx( int n ){
		// return value between 0 and n-1
	       	return rand() % n; 
	};

int RandGenerator::randIdx( int min_v, int max_v ){
	        // return value between min_v and max_v (could be equal or either)
		int n = max_v - min_v + 1;
		return RandGenerator::randIdx( n ) + min_v; 
	};

vector< int > RandGenerator::randPermutation( int n ){
		// randomly permute indices 0 -- n-1
		int tmpi, i, tmp_rand;
		vector< int > idxList( n, 0 );
		for ( i = 0; i < n; i ++ )
			idxList[i] = i;
		for ( i = 0; i < n; i ++ ){
			tmp_rand = RandGenerator::randIdx( i, n-1 );
			tmpi = idxList[ tmp_rand ];
			idxList[ tmp_rand ] = idxList[i];
			idxList[ i ] = tmpi;
		}
		return idxList;
	};

double RandGenerator::randDouble( double max_v ){
		return max_v *( (double)rand() / RAND_MAX );
	};


myDoubleMatrix::myDoubleMatrix(int m,int n,double v) { 
	  nrow=m;
	  ncol=n;
	  int i,j;
	  for (i=0;i<nrow;i++)
		  data.push_back(vector< double >(ncol,v));
	  return;
  };

double myDoubleMatrix::get(int r, int c) { 
	 	MY_ASSERT(((0<=r)&&(r<nrow)), "%s\n", "ERROR");
	 	MY_ASSERT(((0<=c)&&(c<ncol)), "%s\n", "ERROR");
	     return data[r][c];
  };

void myDoubleMatrix::put(int r, int c, double v) { 
	 	MY_ASSERT((0<=r)&&(r<nrow), "%s\n", "ERROR");
	 	MY_ASSERT((0<=c)&&(c<ncol), "%s\n", "ERROR");
	        data[r][c]=v;
  };

void myDoubleMatrix::input1D(double *ptr){
	  int i,j;
	  for (i=0;i<nrow;i++)
		  for (j=0;j<ncol;j++)
			  data[i][j]=ptr[j*nrow+i];
  };

void myDoubleMatrix::output1D(double *ptr){
	  int i,j;
	  for (i=0;i<nrow;i++)
		  for (j=0;j<ncol;j++)
			  ptr[j*nrow+i]=data[i][j];
  };

// Mod-2 addition of two binary vectors (stored as two vectors of nonzero indices)
// We avoid excessive allocations by calculating the size of the resulting list.
// Then we resize the result and populate it with the actual values.
vector< int > vec_sym_diff(vector< int > &sa, vector< int > &sb){
	//assume inputs are both sorted increasingly	
	size_t count = 0;
	Counter< vector< int > > counter(count);
	set_symmetric_difference(sa.begin(), sa.end(), sb.begin(), sb.end(), counter);
	vector< int > out;	
	
	out.reserve(count);
	set_symmetric_difference(sa.begin(), sa.end(), sb.begin(), sb.end(), back_inserter(out));	

	return out;
}

// list<int> list_sym_diff(list<int> sa ,list<int> sb ){
// 	//assume inputs are both sorted increasingly
// 	
// 	sa.push_back(BIG_INT);
// 	sb.push_back(BIG_INT);
// 	list<int> sc;
// 
// 	list<int>::iterator ia=sa.begin();
// 	list<int>::iterator ib=sb.begin();
// 
// 	while(!((* ia==BIG_INT)&&(* ib==BIG_INT))){
// 		if (*ia < *ib){
// 		       sc.push_back(* ia);
// 		       ia++;
// 		}else if(*ia > *ib){ 
// 			sc.push_back(* ib);
// 			ib++;
// 		}else if(*ia != BIG_INT){
// 			ia ++;
// 			ib ++;
// 		}
// 	};
// 	return sc;
// }


// #######################################################
// To be handled. global elements.

