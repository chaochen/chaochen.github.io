function [labels, E, EData, ESmooth] = my_binary_graphcut( dfg, dbg, binary_weight, wLeft, wUp, wUpLeft, wUpRight)

% label 0 is bg
% label 1 is fg

[NRows,NCols]=size(dfg);

NPixels=NRows*NCols;

unaries0 = dbg(:)';
unaries1 = dfg(:)';

bweight=max(0,binary_weight);
binaries = [];

[CIdx,RIdx]=meshgrid(1:NCols, 1:NRows);

% left binaries
CIdxLeft = CIdx-1;
RIdxLeft = RIdx;
IdxLeft = -1 * ones( NRows, NCols );
IdxLeft( :, 2:end ) = sub2ind([NRows, NCols], RIdxLeft( :, 2:end ), CIdxLeft( :, 2:end ));
tmpM = [ 1:NPixels; IdxLeft(:)'; bweight * wLeft(:)'; bweight * wLeft(:)' ];
binaries = [binaries, tmpM(:, tmpM(2,:)>=0)];

% up binaries
CIdxUp = CIdx;
RIdxUp = RIdx-1;
IdxUp = -1 * ones( NRows, NCols );
IdxUp( 2:end, : ) = sub2ind([NRows, NCols], RIdxUp( 2:end, : ), CIdxUp( 2:end, : ));
tmpM = [ 1:NPixels; IdxUp(:)'; bweight * wUp(:)'; bweight * wUp(:)' ];
binaries = [binaries, tmpM(:, tmpM(2,:)>=0)];

% upleft binaries
CIdxUpLeft = CIdx-1;
RIdxUpLeft = RIdx-1;
IdxUpLeft = -1 * ones( NRows, NCols );
IdxUpLeft( 2:end, 2:end ) = sub2ind([NRows, NCols], RIdxUpLeft( 2:end, 2:end ), CIdxUpLeft( 2:end, 2:end ));
tmpM = [ 1:NPixels; IdxUpLeft(:)'; bweight * wUpLeft(:)'; bweight * wUpLeft(:)' ];
binaries = [binaries, tmpM(:, tmpM(2,:)>=0)];

% upright binaries
CIdxUpRight = CIdx+1;
RIdxUpRight = RIdx-1;
IdxUpRight = -1 * ones( NRows, NCols );
IdxUpRight( 2:end, 1:end-1 ) = sub2ind([NRows, NCols], RIdxUpRight( 2:end, 1:end-1 ), CIdxUpRight( 2:end, 1:end-1 ));
tmpM = [ 1:NPixels; IdxUpRight(:)'; bweight * wUpRight(:)'; bweight * wUpRight(:)' ];
binaries = [binaries, tmpM(:, tmpM(2,:)>=0)];

[E, labels_tmp] = mexMaxflow( unaries0, unaries1, binaries );

labels=reshape(labels_tmp,[NRows,NCols]);

EData = E;
ESmooth = E;

