mex CC=gcc-4.3 CXX=g++-4.3 LD=g++-4.3 -O mexMaxflow.cpp maxflow.cpp graph.cpp utils.cpp debugger.cpp

