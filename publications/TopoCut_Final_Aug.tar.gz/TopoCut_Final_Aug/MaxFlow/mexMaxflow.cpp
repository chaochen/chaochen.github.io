#include "mex.h"

#include "debugger.h"
#include "utils.h"

#include <stdio.h>
#include "graph.h"

using namespace std;

extern void _main();

// Function declarations.
// -----------------------------------------------------------------
double getMatlabScalar (const mxArray* ptr) {

  // Make sure the input argument is a scalar in double-precision.
  MY_ASSERT( (mxIsDouble(ptr) && mxGetNumberOfElements(ptr) == 1), "%s\n", "The input argument must be a double-precision scalar");

  return *mxGetPr(ptr);
}

double& createMatlabScalar (mxArray*& ptr) { 
  ptr = mxCreateDoubleMatrix(1,1,mxREAL);
  return *mxGetPr(ptr);
}


const int numInputArgs  = 3; // input:  unaries 0, unaries 1, binaries
const int numOutputArgs = 2; // output: segmentation, and energy 

void mexFunction (int nlhs, mxArray *plhs[],
		  int nrhs, const mxArray *prhs[]) {
 
  DebuggerClass::init( true );

  // Check to see if we have the correct number of input and output arguments.
  MY_ASSERT((nrhs == numInputArgs), "Incorrect number of input arguments, should be %d.\n", numInputArgs);
  MY_ASSERT((nlhs == numOutputArgs), "Incorrect number of output arguments, should be %d.\n", numOutputArgs);
  
  // Read Unaries 0 and Unaries 1 
  int nrow0= mxGetM(prhs[0]); //# of rows
  int ncol0= mxGetN(prhs[0]); //# of cols
  MY_ASSERT( ((nrow0 == 1) && (ncol0 >= 2)), "Incorrect unaries, should be 1*V, V>=2.%s\n", " -- ERROR");
  vector< double > unaries0( mxGetPr(prhs[0]), mxGetPr(prhs[0]) + ncol0 );
  int nvert = ncol0; //# of vertices in the graph

  int nrow1= mxGetM(prhs[1]); //# of rows
  int ncol1= mxGetN(prhs[1]); //# of cols
  MY_ASSERT((nvert == ncol1) && (nrow0 == nrow1), "Unaries for label 1 should be the same dimension as unaries for label 0.%s\n", " -- ERROR");
  vector< double > unaries1( mxGetPr(prhs[1]), mxGetPr(prhs[1]) + ncol1 );

  int nrow2= mxGetM(prhs[2]); //# of rows
  int ncol2= mxGetN(prhs[2]); //# of cols
  MY_ASSERT((nrow2 == 4) && (ncol2 >= 1), "Incorrect binaries, should be 4*E, E>=1.%s\n", " -- ERROR");
  int nedge = ncol2;
  double * tmpptr = mxGetPr(prhs[2]);
  map< pair< int, int >, pair< double, double > > binaries;
  for( int i = 0; i < nedge; i ++ ){
	int tmpvid1 = tmpptr[i*nrow2];
	int tmpvid2 = tmpptr[i*nrow2+1];
	int vid1 = min( tmpvid1, tmpvid2 ) - 1;	// -1 because index in matlab starts with 1
	int vid2 = max( tmpvid1, tmpvid2 ) - 1; // -1 because index in matlab starts with 1

  	MY_ASSERT( ( 0<= vid1 )&&( vid1 < vid2 )&&( vid2 < nvert ), "Invalid edge vertex ids.%s\n", " -- ERROR");
	
	double eweight1 = (tmpvid1 < tmpvid2) ? tmpptr[i*nrow2+2] : tmpptr[i*nrow2+3]; 
	double eweight2 = (tmpvid1 < tmpvid2) ? tmpptr[i*nrow2+3] : tmpptr[i*nrow2+2]; 

  	MY_ASSERT( binaries.find( pair< int, int >( vid1, vid2 ) ) == binaries.end(), "Repeated Edges.%s\n", " -- ERROR");
	binaries[ pair< int, int >( vid1, vid2 ) ] = pair< double, double >( eweight1, eweight2 );

  }
  MY_ASSERT( binaries.size() == nedge, "Binaries size inconsistent.%s\n", " -- ERROR");
  
  //constrct graph
  typedef Graph<double, double, double> GraphType;
  GraphType *g = new GraphType( nvert, nedge ); 

  g -> add_node( nvert ); 

  for( int i = 0; i < nvert; i ++ )
	  g -> add_tweights( i, unaries0[ i ], unaries1[ i ] );

  for( map< pair< int, int >, pair< double, double > >::iterator myit = binaries.begin(); myit != binaries.end(); myit ++ )
	g -> add_edge( myit->first.first, myit->first.second, myit->second.first, myit->second.second );

  double energy = g -> maxflow();
  vector< bool > labeling;
  for( int i = 0; i < nvert; i ++ )
	  labeling.push_back( g->what_segment(i) == GraphType::SOURCE );

  delete g;

  	//writing output  
	
	plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
	double * output_ptr0 = mxGetPr(plhs[0]); 
	output_ptr0[0] = energy;

	plhs[1] = mxCreateDoubleMatrix(1, nvert, mxREAL);
	double * output_ptr1 = mxGetPr(plhs[1]); 
	for( int i = 0; i < nvert; i ++ )
		output_ptr1[ i ] = labeling[ i ];

	OUTPUT_MSG( "Energy = " << energy << endl ); 
  DebuggerClass::finish();

	return ;
}

