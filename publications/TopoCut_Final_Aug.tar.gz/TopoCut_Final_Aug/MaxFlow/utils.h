#ifndef UTILS_H
#define UTILS_H

#include "debugger.h"
#include "mex.h"

#include <exception>
#include <math.h>
#include <queue>
#include <stack>
#include <vector>
#include <map>
#include <set>
#include <list>
#include <assert.h>
#include <algorithm>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>

using namespace std;

// generating random integers and real numbers
class RandGenerator{
public:
	static void init();		// initialize the generator
	static int randIdx( int n );	// generate a random integer >=0 and <=n-1
	static int randIdx( int min_v, int max_v );	// generate a random integer >=min_v and <=max_v
	static vector< int > randPermutation( int n );	// generate a random permutation of 0...n-1
	static double randDouble( double max_v = 1.0 ); // generate a random real number in [ 0, max_v )
};

class myDoubleMatrix {
	public:
		int nrow;
		int ncol;
		vector< vector< double > > data;
  myDoubleMatrix(int ,int ,double v=0.0);  
  
  double get(int , int ) ;

  void put(int , int , double );

  void input1D(double *);

  void output1D(double *);

};  

template <class Container>
struct Counter : public std::iterator <std::output_iterator_tag,
                         void, void, void, void>
{ 
	size_t &cnt;

    Counter(size_t &x) : cnt(x) {}	
 
	template<typename t>
    Counter& operator=(t)
	{        
        return *this;
    }
    
    Counter& operator* () 
	{
        return *this;
    }
    
    Counter& operator++(int) 
	{
		++cnt;
        return *this;
    }    

	Counter& operator++() 
	{
		++cnt;
        return *this;
    }    
};

// Mod-2 addition of two binary vectors (stored as two vectors of nonzero indices)
// We avoid excessive allocations by calculating the size of the resulting list.
// Then we resize the result and populate it with the actual values.
vector< int > vec_sym_diff(vector< int > &, vector< int > &);

// list<int> list_sym_diff(list<int> sa ,list<int> sb ){
// 	//assume inputs are both sorted increasingly
// 	
// 	sa.push_back(BIG_INT);
// 	sb.push_back(BIG_INT);
// 	list<int> sc;
// 
// 	list<int>::iterator ia=sa.begin();
// 	list<int>::iterator ib=sb.begin();
// 
// 	while(!((* ia==BIG_INT)&&(* ib==BIG_INT))){
// 		if (*ia < *ib){
// 		       sc.push_back(* ia);
// 		       ia++;
// 		}else if(*ia > *ib){ 
// 			sc.push_back(* ib);
// 			ib++;
// 		}else if(*ia != BIG_INT){
// 			ia ++;
// 			ib ++;
// 		}
// 	};
// 	return sc;
// }


// #######################################################
// To be handled. global elements.

#define BIG_INT 0xFFFFFFF

#endif
