function [labels_org,labels,n_iters,ncomp_left,nhole_left]=seg_topofix(...
	unary_fg,unary_bg,bw_left,bw_up,bw_ul,bw_ur,smooth_weight,...
	MaxFixIter,CompNumUpperBd, HoleNumUpperBd )

%   input:
% 	unary_fg,unary_bg,bw_left,bw_up,bw_ul,bw_ur, smooth_weight,-- parameters for graph cut
%	MaxFixIter -- max number of iterations of topology fixing
%       CompNumUpperBd -- Upperbound of number of components remaining
%                         if no upperbound, set as -1
%       CompNumUpperBd -- Upperbound of number of holes remaining
%                         if no upperbound, set as -1

if( CompNumUpperBd < 0 )
    disp( 'No upperbound for number of components.' );
elseif( CompNumUpperBd < 1 )
    disp( 'ERROR: Setting upperbound of component to be 0.' );
else
    disp( [ 'Upperbound for number of components = ', int2str(CompNumUpperBd) ] );
end

if( HoleNumUpperBd < 0 )
    disp( 'No upperbound for number of holes.' );
else
    disp( [ 'Upperbound for number of holes = ', int2str(HoleNumUpperBd) ] );
end
    
[labels_org, energy, edata, esmooth] = my_binary_graphcut(unary_fg,unary_bg,smooth_weight,bw_left,bw_up,bw_ul,bw_ur);

labels=labels_org;	%1 is fg, 0 is bg
ufg=unary_fg;
ubg=unary_bg;

n_iters=0;

if ((min(labels(:))==0)&(max(labels(:))==1))
for(i = 1:MaxFixIter)
n_iters=i;

density_function=ufg-ubg;
big_val=max(abs(density_function(:)));
phi=density_function;
phi(labels==1) = phi(labels==1)-big_val;
phi(labels==0) = phi(labels==0)+big_val;

epsilon=0.000001 * rand( size(phi) );	% small perturbation to avoid degenerate case (phi(x)=0)
phi=phi-epsilon;

[perturbM_0d,num_comp,num_hole]=mexTopofix(phi,CompNumUpperBd, HoleNumUpperBd );

disp( [ 'Iteration # ', int2str(n_iters) ] );
disp( [ 'Before fixing, number of components = ', int2str(num_comp) ] );
disp( [ 'Before fixing, number of holes = ', int2str(num_hole) ] );

ncomp_left = num_comp;
nhole_left = num_hole;

if((CompNumUpperBd < 0) & (HoleNumUpperBd < 0))
    break;
end
if( CompNumUpperBd == 0 )
    ncomp_left = 0;
    nhole_left = 0;
    labels = zeros( size(labels_org) );
    break;
end
if( ((CompNumUpperBd < 1)|(num_comp <= CompNumUpperBd)) & ((HoleNumUpperBd < 0)|(num_hole <= HoleNumUpperBd)) )
    labels = (phi<0);
    break;
end;

% fixing
idx_movedown=(perturbM_0d>0)&(labels==0);
ufg(idx_movedown) = ufg(idx_movedown) - 0.5*big_val;
ubg(idx_movedown) = ubg(idx_movedown) + 0.5*big_val;
idx_moveup = (perturbM_0d<0)&(labels==1);
ufg(idx_moveup) = ufg(idx_moveup) + 0.5*big_val;
ubg(idx_moveup) = ubg(idx_moveup) - 0.5*big_val;

% % % fixing
% % fixing_weight = 0.8;    % used to adjust unaries according to topology
% % fixing_const = 10;
% % 
% % idx_movedown=(perturbM_0d>0)&(labels==0);
% % ufg(idx_movedown) = ufg(idx_movedown) - 0.5*fixing_weight*(abs(density_function(idx_movedown))+fixing_const);
% % ubg(idx_movedown) = ubg(idx_movedown) + 0.5*fixing_weight*(abs(density_function(idx_movedown))+fixing_const);
% % 
% % idx_moveup = (perturbM_0d<0)&(labels==1);
% % ufg(idx_moveup) = ufg(idx_moveup) + 0.5*fixing_weight*(abs(density_function(idx_moveup))+fixing_const);
% % ubg(idx_moveup) = ubg(idx_moveup) - 0.5*fixing_weight*(abs(density_function(idx_moveup))+fixing_const);

[labels, energy, edata, esmooth] = my_binary_graphcut(ufg,ubg,smooth_weight,bw_left,bw_up,bw_ul,bw_ur);

end; % end of for i=1:MaxFixIter
else
    disp( [ 'Degenerate Case: initial Seg has Single Label (all zero or all one) .' ] );
    ncomp_left = min( labels(:) );
    ncomp_hole = 0;
end; % end of if 


