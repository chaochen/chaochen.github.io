mex CC=gcc-4.3 CXX=g++-4.3 LD=g++-4.3 -O mexTopofix.cpp

