setmypath;

load bush.mat;

MaxFixIter = 10;        % maximum number of topology fixing iterations
			% after this many iterations the program stop anyway

% upperbounds of number of components and holes
%
% ncomp_ub < 0: no upperbound for number of components
% otherwise, topofix would fix so that the number of components is at most ncomp_ub
% nhole_ub < 0: no upperbound for number of holes
% otherwise, topofix would fix so that the number of holes is at most nhole_ub

% 1 connected component, unlimited number of holes
ncomp_ub = 1;
nhole_ub = -1;

% % any number of component, at most 3 holes
% ncomp_ub = -1;
% nhole_ub = 3;

% % at most 2 components, at most 3 holes
% ncomp_ub = 2;
% nhole_ub = 3;

smooth_weight = 1.8;   % binary weight for graph cut

[labels_org,labels_new,n_iters,ncomp_left,nhole_left]=seg_topofix(...
	unary_fg,unary_bg,wL,wU,wUL,wUR,smooth_weight,...
	MaxFixIter, ncomp_ub, nhole_ub );

close all;
figure, imshow( I, [] );
figure, imshow( labels_org, []);  % the original segmentation, 1 is fg, 0 is bg
figure, imshow( labels_new, []);  % after fixing
