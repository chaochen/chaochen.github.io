TopoCut Code. Version 1.1 
Chao Chen
chao.chen@ist.ac.at
--------------------------------------------

* COMPILE

The code is compiled in linux 64bit machine, using matlab and g++-4.3.
to compile:
execute mexCompile inside MaxFlow folder and TopoFix folder respectively.

* USAGE

Please check the example.m for example. It loads unaries and binaries, and then calls the function seg_topfix.

The returned labels_org is the original graphcut result.
             labels_new is the result with topology fixed.

ncomp_ub and nhole_ub specify upperbounds of number of components and holes. Set them to be negative if you do not want an upperbound.

smooth_weight is the weight of the binary term.
It depends on the unaries and binaries.
You have to set it correct so that graph cut give you some sensible result. 
Otherwise topology fixing would not make sense. 
You could choose the best smooth_weight like what we did in the paper.

* CITATION

To Use the Code, Please Cite
        "Enforcing Topological Constraints in Random Field Image Segmentation."
	Chao Chen and Daniel Freedman and Christoph H. Lampert
	In In IEEE Conference on Computer Vision and Pattern Recognition (CVPR), 
	June 2011

Our code uses the binary graphcut implementation (MAXFLOW) by Boykov and Kolmogorov
http://http://pub.ist.ac.at/~vnk/software.html 

	"An Experimental Comparison of Min-Cut/Max-Flow Algorithms for Energy Minimization in Vision."
        Yuri Boykov and Vladimir Kolmogorov.
        In IEEE Transactions on Pattern Analysis and Machine Intelligence (PAMI), 
        September 2004

Please cite their paper as well.

