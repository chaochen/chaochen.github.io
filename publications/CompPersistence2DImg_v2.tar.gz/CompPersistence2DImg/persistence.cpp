/*****************************************************************************
*   Computing Persistence for 2D Image
*                        Version 2.0                                         
*    http://research.cs.rutgers.edu/~cc1092/
*    Written by Chao Chen (chao.chen.cchen@gmail.com)
*    Aug. 2014
*****************************************************************************/
#include "persistence.h"

VertEdgePair::VertEdgePair(int vbi, int edi, float per, int edi2, int edidx, float birth, float death) : 
  vbVertIdx(vbi),edVertIdx(edi),
  pers_val(per),edVertIdx2(edi2),edIdx(edidx),
  birth_val(birth),death_val(death){};
  
bool VertEdgePair::operator<(const VertEdgePair &rhs) const{
    return (this->pers_val >= rhs.pers_val);
  };

EdgeFacePair::EdgeFacePair( int ebi, int fdi, float per, int ebidx, int fdidx, float birth, float death) : 
  ebVertIdx(ebi),fdVertIdx(fdi),
  pers_val(per),ebIdx(ebidx),fdIdx(fdidx),
  birth_val(birth),death_val(death){};

bool EdgeFacePair::operator<(const EdgeFacePair &rhs) const{
    return (this->pers_val >= rhs.pers_val);
  };

void Persistence::calcPers(const int m,const int n, const double pers_thd, int maxdegree, long double * degreep){
  
	OUTPUT_MSG("Begin computing persistence");

	//constructing vList
	int i,j;
	
	for(i=0;i<maxdegree;i++) degreep[i]=0;
	
	double tmp_pers;
	
	for (i=0;i<m;i++)
		for (j=0;j<n;j++)
			vList->push_back(Vertex(i,j,phi->data[i][j]));
 
	//sort vList
	sort(vList->begin(), vList->end());

	OUTPUT_MSG("--vList constructed and sorted");

	myCM=new CellMap(vList,eList,fList, phi->nrow, phi->ncol);

	//construct and reduce 2d boundary matrix
	vector< vector< int > > * boundary_2D=new vector< vector< int > >((* myCM).faceNum, vector< int >()); //first index is col index, each col init to empty
	(* myCM).buildBoundary2D(boundary_2D);
	vector< int > * low_2D_e2t=new vector< int >((* myCM).edgeNum,-1);

	int num_e_creator=0;
	int num_t_destroyer=0;
	int num_v_creator=0;// number of vertices creating non-essential class
	int num_e_destroyer=0;// number of edge destroyer (non-essential)

	//output edge-face pairs whose persistence is bigger than pers_thd
	int vBirth,vDeath;
	int tmp_int;
	double tmp_death,tmp_birth;
	
	int low;

	list<int>::iterator myiter;
	int tmpe12,tmpe23,tmpe13;
	map<int, int>::iterator tmpit;
 vector<int> tmp_vint;
	for (i=0;i<(* myCM).faceNum;i++){

		//reduce column i
		low = * (* boundary_2D)[i].rbegin();

		while ( ( ! (* boundary_2D)[i].empty() ) && ( (* low_2D_e2t)[low]!=-1 ) ){
			(* boundary_2D)[i]=vec_sym_diff((* boundary_2D)[i],(* boundary_2D)[(* low_2D_e2t)[low]]);

			if(! (* boundary_2D)[i].empty()){
				low = * (* boundary_2D)[i].rbegin();
			}
		}

  if( (! (* boundary_2D)[i].empty()) && use_smart_reduction_strategy ){
    // heuristic strategy: reduce further after the pair is found
    int idx_from_end = 1;
    int tmp_low;
    assert( * (* boundary_2D)[i].rbegin() == low );
    while( idx_from_end < (* boundary_2D)[i].size() ){
      tmp_low = * ((* boundary_2D)[i].rbegin() + idx_from_end);
      if( (* low_2D_e2t)[tmp_low] != -1 ){
/*        
        tmp_vint = (* boundary_2D)[i]; // copy current column
					   tmp_vint =vec_sym_diff(tmp_vint,(* boundary_2D)[(* low_2D_e2t)[tmp_low]]);  // reduce tmp_vint

        if( tmp_vint.size() < (* boundary_2D)[i].size() ){
          (* boundary_2D)[i] = tmp_vint;
        }else{
          ++ idx_from_end;
        }
*/        
					   (* boundary_2D)[i] =vec_sym_diff((* boundary_2D)[i],(* boundary_2D)[(* low_2D_e2t)[tmp_low]]);
      }else{
        ++ idx_from_end;
      }
    }
  }	

		if (! (* boundary_2D)[i].empty()){

			MY_ASSERT((low>=0), "%s\n", "ERROR");
			MY_ASSERT(((* low_2D_e2t)[low]==-1), "%s\n", "ERROR");
			(* low_2D_e2t)[low]=i;
			num_t_destroyer++;
			num_e_creator++;

			//record pair
			Edge edgeCreator=(* eList)[low];
			Face faceDestroyer=(* fList)[i];
			vBirth= edgeCreator.v2_order;
			vDeath= faceDestroyer.v4_order;
			tmp_death=phi->data[(* vList)[vDeath].xidx][(* vList)[vDeath].yidx];
			tmp_birth=phi->data[(* vList)[vBirth].xidx][(* vList)[vBirth].yidx];

			tmp_pers=max(0.0,tmp_death-tmp_birth);
			    for(int p=0;p<maxdegree;p++)
				degreep[p]=degreep[p]+max(0.0,pow(tmp_pers,double(p+1)));


			if(tmp_pers>pers_thd){
			    //recording pers pairs
       // low is the birth edge idx, i is the death face idx
			    efPersList->push_back(EdgeFacePair(vBirth, vDeath, tmp_pers, low, i, tmp_birth, tmp_death));

			}
		}else{
			MY_ASSERT((false), "%s\n", "ERROR");
		}

		if (i % 100000 == 0)
		  OUTPUT_MSG( "reducing boundary 2D: i=" << i <<", face number=" << (* myCM).faceNum );
	}
	
	(* myCM).setEPersType( low_2D_e2t );

	set < int > bigt;
	int hole_creator;
	int hole_ct = 0;
	int new_holes_created=0;

	OUTPUT_MSG( "boundary_2D all reduced" );
 if(save_2D_generators){
	  OUTPUT_MSG( "boundary_2D saved for generator computation" );
   boundary_2D_ptr = boundary_2D;
 }else
	  delete boundary_2D;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//construct and reduce 1d boundary matrix

	vector< int > * low_1D_v2e= new vector< int >((* myCM).vertNum,-1);
	// for each creator vertex, store the edge it is paired to
	
	vector< vector< int > > * boundary_1D=new vector< vector< int > >((* myCM).edgeNum, vector< int >()); //first index is col index, each col init to empty
	(* myCM).buildBoundary1D(boundary_1D);

	int tmptmp=0;
	int tmptmptmp=0;

	for (i=0;i<(* myCM).edgeNum;i++){

		if ( (* low_2D_e2t)[i] >= 0 ){ 
			(*boundary_1D)[i].clear();
			tmptmp++;
		  continue;
		}else{
			tmptmptmp++;
		  MY_ASSERT(((* low_2D_e2t)[i] == -1), "%s\n", "ERROR");
		  MY_ASSERT(((*boundary_1D)[i].size()==2), "%s\n", "ERROR");
		};
	  
		//reduce column i
		low = * (* boundary_1D)[i].rbegin();

		while ( ( ! (* boundary_1D)[i].empty() ) && ( (* low_1D_v2e)[low]!=-1 ) ){
			(* boundary_1D)[i]=vec_sym_diff((* boundary_1D)[i],(* boundary_1D)[(* low_1D_v2e)[low]]);
			if(! (* boundary_1D)[i].empty()){
				low = * (* boundary_1D)[i].rbegin();
			}
		}
		if (! (* boundary_1D)[i].empty()){
			MY_ASSERT((low>=0), "%s\n", "ERROR");
			MY_ASSERT(((* low_1D_v2e)[low]==-1), "%s\n", "ERROR");
			(* low_1D_v2e)[low]=i;
			num_e_destroyer++;
			num_v_creator++;

			MY_ASSERT(((* boundary_1D)[i].size()==2), "%s\n", "ERROR");
			
			int high =  * (* boundary_1D)[i].begin();
			//reduce high
			while (  (* low_1D_v2e)[high]!=-1 ){
				int edge_high=(*low_1D_v2e)[high];
				(* boundary_1D)[i]=vec_sym_diff((* boundary_1D)[i],(* boundary_1D)[edge_high]);
				MY_ASSERT(((* boundary_1D)[i].size()==2), "%s\n", "ERROR");
				high = * (* boundary_1D)[i].begin();
			}

			//record pair
			vBirth= low;	//creator vertex
			Edge eDestroyer = (* eList)[i];
			vDeath=eDestroyer.v2_order;
			tmp_death=phi->data[(* vList)[vDeath].xidx][(* vList)[vDeath].yidx];
			tmp_birth=phi->data[(* vList)[vBirth].xidx][(* vList)[vBirth].yidx];
			
			tmp_pers=max(0.0,tmp_death-tmp_birth);
			    for(int p=0;p<maxdegree;p++)
				degreep[p]=degreep[p]+pow(tmp_pers,double(p+1));

			int vDeath1=eDestroyer.v1_order; // the other vert of the death edge

			if(tmp_pers>pers_thd){
			    //recording pers pairs
			    vePersList->push_back(VertEdgePair(vBirth, vDeath, tmp_pers, vDeath1, i, tmp_birth, tmp_death));

			}


		}else{
			MY_ASSERT((false), "%s\n", "ERROR");
		}

		if (i % 100000 == 0)
		  OUTPUT_MSG( "reducing boundary 1D: i=" << i <<", edge number=" << (* myCM).edgeNum );
	}
	MY_ASSERT((num_v_creator==(* myCM).vertNum-1), "%s\n", "ERROR");
	MY_ASSERT((num_e_destroyer==num_v_creator), "%s\n", "ERROR");
// 	MY_ASSERT((num_e_creator+num_e_destroyer==(* myCM).edgeNum), "%s\n", "ERROR");
// 	MY_ASSERT((num_t_destroyer==(* myCM).faceNum), "%s\n", "ERROR");
	OUTPUT_MSG( "boundary 1D all reduced" );

	
	delete low_1D_v2e;
	delete low_2D_e2t;
	delete boundary_1D;

	sort(vePersList->begin(),vePersList->end());
	sort(efPersList->begin(),efPersList->end());

};

// output zero dim pers, 
// old version for matlab
void Persistence::outputVEL(double *ptr){
	  int ncol = vePersList->size();
	  int nrow = persPairSize;

	  int i,j;

	  for (j=0;j<ncol;j++){
		ptr[ j*nrow+0 ] = (double) (* vList)[(* vePersList)[j].vbVertIdx].xidx+1;
		ptr[ j*nrow+1 ] = (double) (* vList)[(* vePersList)[j].vbVertIdx].yidx+1;
//		ptr[ j*nrow+2 ] = (double) (* vList)[(* vePersList)[j].edVertIdx].xidx+1;
//		ptr[ j*nrow+3 ] = (double) (* vList)[(* vePersList)[j].edVertIdx].yidx+1;
		ptr[ j*nrow+2 ] = (double) (* vePersList)[j].pers_val;
	  };

	  return;
};

// output zero dim pers, 
// new version for text output
void Persistence::outputVEL(fstream * fs_ptr, const int m,const int n, const double pers_thd){
  assert(fs_ptr->good());
  (* fs_ptr) << "PersistenceThreshold " << pers_thd << endl;  
  (* fs_ptr) << "DomainSize " << m << " by " << n << endl;  
  (* fs_ptr) << "Dimension 0" << endl;  
  (* fs_ptr) << "NumberOfDots " << vePersList->size() << endl;  

  for(int i = 0; i < vePersList->size(); ++i){
    (* fs_ptr) << "DotIDX " << i << endl; 
    (* fs_ptr) << "BirthDeathPersistence " << (* vePersList)[i].birth_val << " " << (* vePersList)[i].death_val << " " << (* vePersList)[i].pers_val << endl;
    int vid = (* vePersList)[i].vbVertIdx;
    int eid = (* vePersList)[i].edIdx;
    assert( (vid>=0)&&(vid<myCM->vertNum) );
    assert( (eid>=0)&&(eid<myCM->edgeNum) );
    
    (* fs_ptr) << "BirthVertex " << (* vList)[vid].xidx << " " << (* vList)[vid].yidx << endl;

    int tmpv;
    (* fs_ptr) << "DeathEdge";
    tmpv = (* eList)[eid].v1_order;
    (* fs_ptr) << " " << (* vList)[tmpv].xidx << " " << (* vList)[tmpv].yidx;
    tmpv = (* eList)[eid].v2_order;
    (* fs_ptr) << " " << (* vList)[tmpv].xidx << " " << (* vList)[tmpv].yidx;
    (* fs_ptr) << endl;
  }
};

pair<int, int> Persistence::growComponent(int seedv, Mat & mask, int eid_ub ){
  
   stack<int> mystack;
   mystack.push(seedv);
   vector<int> nb_list;
   int tmpv, tmpe, xidx, yidx, tmpv2, x2idx, y2idx;

     xidx = (* vList)[seedv].xidx;
     yidx = (* vList)[seedv].yidx;
     mask.at<uchar>(xidx,yidx) = 255;

  int maxx = -1;
  int minx = INT_MAX;
  int maxy = -1;
  int miny = INT_MAX;

   while( ! mystack.empty() ){
     int tmpv = mystack.top();
     mystack.pop();
    
     xidx = (* vList)[tmpv].xidx;
     yidx = (* vList)[tmpv].yidx;
     maxx = max(maxx, xidx);
     maxy = max(maxy, yidx);
     minx = min(minx, xidx);
     miny = min(miny, yidx);

     if(xidx > 0){
        x2idx = xidx-1;
        y2idx = yidx;
        tmpv2 = (* myCM).getVertIdx(x2idx,y2idx);
        tmpe = (* myCM).getEdgeIdx(xidx, yidx, x2idx, y2idx);
        if( (tmpe < eid_ub) && (mask.at<uchar>(x2idx,y2idx) == 0) ){
          mystack.push(tmpv2);
          mask.at<uchar>(x2idx,y2idx) = 255;
        }
     } 

     if(yidx > 0){
        x2idx = xidx;
        y2idx = yidx-1;
        tmpv2 = (* myCM).getVertIdx(x2idx,y2idx);
        tmpe = (* myCM).getEdgeIdx(xidx, yidx, x2idx, y2idx);
        if( (tmpe < eid_ub) && (mask.at<uchar>(x2idx,y2idx) == 0) ){
          mystack.push(tmpv2);
          mask.at<uchar>(x2idx,y2idx) = 255;
        }
     } 
    
     if(xidx < phi->nrow-1){
        x2idx = xidx+1;
        y2idx = yidx;
        tmpv2 = (* myCM).getVertIdx(x2idx,y2idx);
        tmpe = (* myCM).getEdgeIdx(xidx, yidx, x2idx, y2idx);
        if( (tmpe < eid_ub) && (mask.at<uchar>(x2idx,y2idx) == 0) ){
          mystack.push(tmpv2);
          mask.at<uchar>(x2idx,y2idx) = 255;
        }
     } 

     if(yidx < phi->ncol-1){
        x2idx = xidx;
        y2idx = yidx+1;
        tmpv2 = (* myCM).getVertIdx(x2idx,y2idx);
        tmpe = (* myCM).getEdgeIdx(xidx, yidx, x2idx, y2idx);
        if( (tmpe < eid_ub) && (mask.at<uchar>(x2idx,y2idx) == 0) ){
          mystack.push(tmpv2);
          mask.at<uchar>(x2idx,y2idx) = 255;
        }
     } 
   }
   return pair<int,int>(maxx-minx+1, maxy-miny+1);
};

vector<pair<double, pair<Mat, Mat> > > Persistence::outputZeroPersComponents(int noutput, int geom_constraint){
   int num_output = min(noutput, (int) vePersList->size()); 

   vector<pair<double, pair<Mat, Mat> > > ret(num_output);
   
   int nrow = phi->nrow;
   int ncol = phi->ncol;
   pair<int,int> geom_range;
   Mat tmpM1, tmpM2;
   int curr_idx = 0;
   for(int i = 0; i < (* vePersList).size(); ++i){
    
     tmpM1 = Mat::zeros(nrow, ncol, CV_8UC1);
     geom_range = growComponent( (* vePersList)[i].edVertIdx, tmpM1, (* vePersList)[i].edIdx );
     if((geom_range.first < geom_constraint)||(geom_range.second < geom_constraint))
       continue;

     tmpM2 = Mat::zeros(nrow, ncol, CV_8UC1);
     geom_range = growComponent( (* vePersList)[i].edVertIdx2, tmpM2, (* vePersList)[i].edIdx );
     if((geom_range.first < geom_constraint)||(geom_range.second < geom_constraint))
       continue;

     // if geometric constraint is satisfied, save it 
     ret[curr_idx].first = (double) (* vePersList)[i].pers_val;

     int birthv = (* vePersList)[i].vbVertIdx;
     int birthX = (* vList)[birthv].xidx;
     int birthY = (* vList)[birthv].yidx;
    
//     cout << " birth = " << birthX << " " << birthY << endl;

//   Utils::testShowImage(tmpM1, "tM1");
//   Utils::testShowImage(tmpM2, "tM2");
      // either the first or the second mask contains birthv
      assert( ((tmpM1.at<uchar>(birthX,birthY) == 0)&&(tmpM2.at<uchar>(birthX,birthY) != 0))
           || ((tmpM1.at<uchar>(birthX,birthY) != 0)&&(tmpM2.at<uchar>(birthX,birthY) == 0)) );

     if(tmpM1.at<uchar>(birthX,birthY) != 0){
       tmpM1.copyTo(ret[curr_idx].second.first);
       tmpM2.copyTo(ret[curr_idx].second.second);
     }else{
       tmpM2.copyTo(ret[curr_idx].second.first);
       tmpM1.copyTo(ret[curr_idx].second.second);
     }

     ++ curr_idx;
     if(curr_idx >= num_output)
       break;
   }

	  return ret;
};

void Persistence::outputEFL(double *ptr){
	  int ncol = efPersList->size();
	  int nrow = persPairSize;

	  int i,j;

	  for (j=0;j<ncol;j++){
//		ptr[ j*nrow+0 ] = (double) (* vList)[(* efPersList)[j].ebVertIdx].xidx+1;
//		ptr[ j*nrow+1 ] = (double) (* vList)[(* efPersList)[j].ebVertIdx].yidx+1;
		ptr[ j*nrow+0 ] = (double) (* vList)[(* efPersList)[j].fdVertIdx].xidx+1;
		ptr[ j*nrow+1 ] = (double) (* vList)[(* efPersList)[j].fdVertIdx].yidx+1;
		ptr[ j*nrow+2 ] = (double) (* efPersList)[j].pers_val;
	  };

	  return;
};

// output one dim pers, 
// new version for text output
void Persistence::outputEFL(fstream * fs_ptr, const int m,const int n, const double pers_thd, bool write_generators){
  assert(fs_ptr->good());
  Mat org_image, tmp_image; 

#ifdef DEBUG
  Mat org_image_gray;
  phi->outputToMat(org_image_gray);
  cvtColor( org_image_gray, org_image, CV_GRAY2BGR );
#endif

  if(write_generators)
    assert(save_2D_generators);
  (* fs_ptr) << "PersistenceThreshold " << pers_thd << endl;  
  (* fs_ptr) << "DomainSize " << m << " by " << n << endl;  
  (* fs_ptr) << "Dimension 1" << endl;  
  (* fs_ptr) << "NumberOfDots " << efPersList->size() << endl;  

  for(int i = 0; i < efPersList->size(); ++i){
    (* fs_ptr) << "DotIDX " << i << endl; 
    (* fs_ptr) << "BirthDeathPersistence " << (* efPersList)[i].birth_val << " " << (* efPersList)[i].death_val << " " << (* efPersList)[i].pers_val << endl;
    int eid = (* efPersList)[i].ebIdx;
    int fid = (* efPersList)[i].fdIdx;
    assert( (eid>=0)&&(eid<myCM->edgeNum) );
    assert( (fid>=0)&&(fid<myCM->faceNum) );
    
    int tmpv;
    (* fs_ptr) << "BirthEdge";
    tmpv = (* eList)[eid].v1_order;
    (* fs_ptr) << " " << (* vList)[tmpv].xidx << " " << (* vList)[tmpv].yidx;
    tmpv = (* eList)[eid].v2_order;
    (* fs_ptr) << " " << (* vList)[tmpv].xidx << " " << (* vList)[tmpv].yidx;
    (* fs_ptr) << endl;
    (* fs_ptr) << "DeathFace";
    tmpv = (* fList)[fid].v1_order;
    (* fs_ptr) << " " << (* vList)[tmpv].xidx << " " << (* vList)[tmpv].yidx;
    tmpv = (* fList)[fid].v2_order;
    (* fs_ptr) << " " << (* vList)[tmpv].xidx << " " << (* vList)[tmpv].yidx;
    tmpv = (* fList)[fid].v3_order;
    (* fs_ptr) << " " << (* vList)[tmpv].xidx << " " << (* vList)[tmpv].yidx;
    tmpv = (* fList)[fid].v4_order;
    (* fs_ptr) << " " << (* vList)[tmpv].xidx << " " << (* vList)[tmpv].yidx;
    (* fs_ptr) << endl;

    if(write_generators){
#ifdef DEBUG
      org_image.copyTo(tmp_image);
      Vec3b color;
      color[0] = 0;
      color[1] = 0;
      color[2] = 255;
#endif

      (* fs_ptr) << "GeneratorNumberOfEdges " << (* boundary_2D_ptr)[fid].size() << endl; 
      assert( ! (* boundary_2D_ptr)[fid].empty() );
      for(int j = 0; j < (* boundary_2D_ptr)[fid].size(); ++j){
        int tmpe =  (* boundary_2D_ptr)[fid][j];
				    (* fs_ptr) << "GeneratorEdgeIdxAndVertices " << j;
				    tmpv = (* eList)[tmpe].v1_order;
				    (* fs_ptr) << " " << (* vList)[tmpv].xidx << " " << (* vList)[tmpv].yidx;
#ifdef DEBUG
        tmp_image.at<Vec3b>((* vList)[tmpv].xidx, (* vList)[tmpv].yidx) = color;
#endif

				    tmpv = (* eList)[tmpe].v2_order;
				    (* fs_ptr) << " " << (* vList)[tmpv].xidx << " " << (* vList)[tmpv].yidx;
#ifdef DEBUG
        tmp_image.at<Vec3b>((* vList)[tmpv].xidx, (* vList)[tmpv].yidx) = color;
#endif
				    (* fs_ptr) << endl;
      }
#ifdef DEBUG
        Utils::testShowImage( tmp_image, "the current generator" );
#endif

    }
  }
};

