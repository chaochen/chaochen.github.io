/*****************************************************************************
*   Computing Persistence for 2D Image
*                        Version 2.0                                         
*    http://research.cs.rutgers.edu/~cc1092/
*    Written by Chao Chen (chao.chen.cchen@gmail.com)
*    Aug. 2014
*****************************************************************************/
#include "mex.h"

#include "debugger.h"
#include "utils.h"
#include "CubicalComplex.h"
#include "persistence.h"

using namespace std;

extern void _main();

// Function declarations.
// -----------------------------------------------------------------
double getMatlabScalar (const mxArray* ptr) {

  // Make sure the input argument is a scalar in double-precision.
  MY_ASSERT( (mxIsDouble(ptr) && mxGetNumberOfElements(ptr) == 1), "%s\n", "The input argument must be a double-precision scalar");

  return *mxGetPr(ptr);
}

double& createMatlabScalar (mxArray*& ptr) { 
  ptr = mxCreateDoubleMatrix(1,1,mxREAL);
  return *mxGetPr(ptr);
}


const int numInputArgs  = 4;
const int numOutputArgs1 = 1;
const int numOutputArgs2 = 3;

void mexFunction (int nlhs, mxArray *plhs[],
		  int nrhs, const mxArray *prhs[]) {
 
  DebuggerClass::init();

  // Check to see if we have the correct number of input and output arguments.
  MY_ASSERT((nrhs == numInputArgs), "Incorrect number of input arguments, should be %d.\n", numInputArgs);

  double pers_thd=getMatlabScalar(prhs[1]);
  int maxdegree = (int)getMatlabScalar( prhs[2] );
  int outputCP = (int)getMatlabScalar( prhs[3] );

  if (! outputCP ){
  	MY_ASSERT((nlhs == numOutputArgs1), "Incorrect number of output arguments, should be %d.\n", numOutputArgs1);
  }else{
  	MY_ASSERT((nlhs == numOutputArgs2), "Incorrect number of output arguments, should be %d.\n", numOutputArgs2);
  }

  int m= mxGetM(prhs[0]); //# of rows
  int n= mxGetN(prhs[0]); //# of cols

	myDoubleMatrix * phi;
	phi=new myDoubleMatrix(m,n);
	phi->input1D(mxGetPr(prhs[0]));
	
	int i;
	
	long double * degreep=new long double [maxdegree];
	for(i=0;i<maxdegree;i++) degreep[i]=0.0;

	Persistence pers(phi);
	pers.calcPers(m,n,pers_thd,maxdegree,degreep);
	
	OUTPUT_MSG("calcPers is DONE");

	plhs[0] = mxCreateDoubleMatrix(1,maxdegree,mxREAL);
	double * ptr = mxGetPr(plhs[0]);
	for(i=0;i<maxdegree;i++) ptr[i]=pow(degreep[i], 1.0/(i+1));

	
	if ( outputCP ){
  if((pers.getPersPairSize() == 0)||(pers.getVELSize() == 0)){
    cout << "Empty minimum list" << endl;
		  plhs[1] = mxCreateDoubleScalar(0.0);
  }else{
 		 plhs[1] = mxCreateDoubleMatrix(pers.getPersPairSize(), pers.getVELSize(), mxREAL);
		  pers.outputVEL(mxGetPr(plhs[1]));
  }
  if((pers.getPersPairSize() == 0)||(pers.getEFLSize() == 0)){
		  plhs[2] = mxCreateDoubleScalar(0.0);
    cout << "Empty maximum list" << endl;
  }else{
		  plhs[2] = mxCreateDoubleMatrix(pers.getPersPairSize(), pers.getEFLSize(), mxREAL);
		  pers.outputEFL(mxGetPr(plhs[2]));
  }
	};
	    
	delete [] degreep;	
	delete phi;

  DebuggerClass::finish();

	return ;
}

