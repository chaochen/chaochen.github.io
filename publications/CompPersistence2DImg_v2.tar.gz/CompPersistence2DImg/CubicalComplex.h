/*****************************************************************************
*   Computing Persistence for 2D Image
*                        Version 2.0                                         
*    http://research.cs.rutgers.edu/~cc1092/
*    Written by Chao Chen (chao.chen.cchen@gmail.com)
*    Aug. 2014
*****************************************************************************/
#ifndef CUBICALCOMPLEX_H
#define CUBICALCOMPLEX_H

#include "utils.h"
#include "debugger.h"


class Vertex{
	public:
	int xidx;
	int yidx;
	int mapXCoord;
	int mapYCoord;
	double val;
	Vertex(int ,int , double );	
	Vertex();
  	bool operator<(const Vertex &rhs) const;
};

class Edge{
	public:
	int v1_order;
	int v2_order;
	int mapXCoord;
	int mapYCoord;
	Edge(int ,int , int , int );	
	Edge(); 
  	bool operator<(const Edge &rhs) const;
};

class Face{
	public:
	int v1_order;
	int v2_order;
	int v3_order;
	int v4_order;
	int e1_order;
	int e2_order;
	int e3_order;
	int e4_order;
	int mapXCoord;
	int mapYCoord;
	Face(int ,int ,int ,int ,int ,int ,int ,int ,int ,int );
	Face(); 
  	bool operator<(const Face &rhs) const;
};

// bool vCompVal(Vertex , Vertex );

// bool eComp(Edge , Edge ); 

// bool fComp(Face , Face ); 

enum CellTypeEnum {CT_UNDEFINED, VERTEX, EDGEVERT, EDGEHORI, FACE};
enum EdgePersTypeEnum {EP_UNDEFINED, DESTROYER, CREATOR};
class CellMap{
public:
	int vertNum,edgeNum,faceNum;
	int mapNRow, mapNCol;
	int currEOrder, currTOrder;
	vector< vector < int > > cellOrder;
	vector< vector < CellTypeEnum > > cellType;
	
	vector< vector < EdgePersTypeEnum > > edgePersType;
	
	vector< Vertex > * vList;
	vector< Edge > * eList;
	vector< Face > * fList;

	void setVertOrder(int , int , int );

	CellMap(vector< Vertex > * , vector< Edge > * , vector< Face > * , int , int );
	
	void buildBoundary2D(vector<vector < int > > * );
					
	void buildBoundary1D(vector<vector < int > > * );

	void setEPersType( vector< int > * );

 int getVertIdx(int xidx, int yidx){
   // given coordinates on the image (not the cell map), return the corresponding vert idx
   return cellOrder[xidx*2][yidx*2];
 };

 int getEdgeIdx(int x1idx, int y1idx, int x2idx, int y2idx){
   // given coordinates on the image (not the cell map), return the corresponding edge idx

   if(x1idx == x2idx){
     assert((y1idx == y2idx-1)||(y1idx == y2idx+1));
   }else{
     assert((y1idx == y2idx));
     assert((x1idx == x2idx-1)||(x1idx == x2idx+1));
   }
  
   int excoord = x1idx + x2idx;
   int eycoord = y1idx + y2idx;

   return cellOrder[excoord][eycoord];
 };

};	// end of class CellMap

#endif
