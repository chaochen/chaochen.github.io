/*****************************************************************************
*   Computing Persistence for 2D Image
*                        Version 2.0                                         
*    http://research.cs.rutgers.edu/~cc1092/
*    Written by Chao Chen (chao.chen.cchen@gmail.com)
*    Aug. 2014
*****************************************************************************/

#include "debugger.h"
#include "utils.h"
#include "CubicalComplex.h"
#include "persistence.h"

using namespace cv;
using namespace std;

int main( int argc, char** argv )
{
  if( ( argc != 2) &&( argc != 3) && (argc != 4) )
  {
    cout <<" Usage: ./persImage image-name pers-thd use-smart-reduction-strategy" << endl;
    return -1;
  }

  double pers_thd = 0.01;
  if( argc >= 3 ){
    pers_thd = atof(argv[2]);
    cout << "persistence threshold = " << pers_thd << endl;
  }
  int use_smart_reduction_strategy = 0;
  if( argc >= 4 ){
    use_smart_reduction_strategy = atoi(argv[3]);
    if( use_smart_reduction_strategy != 0 )
      cout << "using smart reduction strategy to get shorter generators " << endl;
  }


  Mat image;
  image = imread(argv[1], CV_LOAD_IMAGE_COLOR);   // Read the file

  string infname = string(argv[1]);
  if(! image.data )                              // Check for invalid input
  {
    cout <<  "Could not open or find the image : " << argv[1] << endl ;
    return -1;
  }

  if( image.type() != CV_8UC3 ){
    cout << "Image type is not CV_8UC3" << endl;
    return -1;
  }

  Mat gray_image;
  cvtColor( image, gray_image, CV_BGR2GRAY );
  assert( gray_image.type() == CV_8UC1 );
#ifdef DEBUG
  Utils::testShowImage( gray_image, "input image (gray)" );
#endif

//    namedWindow( "Display window", WINDOW_AUTOSIZE );// Create a window for display.
//    imshow( "Display window", gray_image );                   // Show our gray_image inside it.
//  
//    waitKey(0);                                          // Wait for a keystroke in the window

  myDoubleMatrix * phi;
	 phi=new myDoubleMatrix(gray_image.rows, gray_image.cols);
	 phi->inputFromMat(gray_image);

//  Mat gi2;
//  phi->outputToMat(gi2);
//  Utils::testShowImage( gi2 );

  int maxdegree = 3;
	 long double * degreep=new long double [maxdegree];

	Persistence pers(phi, use_smart_reduction_strategy);
 pers.set_save_2D_generators(); // set save_2D_generators before calcPers
	pers.calcPers(phi->nrow, phi->ncol, pers_thd, maxdegree,degreep);
  
 string outfname0 = infname + string(".PersDim0");
 fstream filestr0;
 filestr0.open(outfname0.c_str(), fstream::in | fstream::out | fstream::trunc);
 pers.outputVEL( & filestr0, phi->nrow, phi->ncol, pers_thd ); 
 filestr0.close();

 string outfname1 = infname + string(".PersDim1");
 fstream filestr1;
 filestr1.open(outfname1.c_str(), fstream::in | fstream::out | fstream::trunc);
 bool write_generators = true;
 pers.outputEFL( & filestr1, phi->nrow, phi->ncol, pers_thd, write_generators ); 
 filestr1.close();

	 delete [] degreep;	
	 delete phi;
  return 0;
}
