#!/bin/bash
while read line
do
echo ${line}
persImage ${line} 4 10
done
