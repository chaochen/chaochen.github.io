delete('mexPersistence.mexa64');
mex -O CXX=g++-4.4 CC=gcc-4.4 LD=g++-4.4 mexPersistence.cpp persistence.cpp CubicalComplex.cpp utils.cpp debugger.cpp
%mex -g CXX=g++-4.4 CC=gcc-4.4 LD=g++-4.4 mexPersistence.cpp persistence.cpp CubicalComplex.cpp utils.cpp debugger.cpp

