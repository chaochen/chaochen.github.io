/*****************************************************************************
*   Computing Persistence for 2D Image
*                        Version 2.0                                         
*    http://research.cs.rutgers.edu/~cc1092/
*    Written by Chao Chen (chao.chen.cchen@gmail.com)
*    Aug. 2014
*****************************************************************************/
#include "CubicalComplex.h"

Vertex::Vertex(int xi,int yi,double v) : 
	xidx(xi),yidx(yi),mapXCoord(xi*2),mapYCoord(yi*2),val(v){};

Vertex::Vertex() : xidx(-1),yidx(-1),mapXCoord(-1),mapYCoord(-1),val(-1.0){};

Edge::Edge(int v1o,int v2o, int mx, int my) : 
	v1_order(min(v1o,v2o)),v2_order(max(v1o,v2o)),mapXCoord(mx),mapYCoord(my){};

Edge::Edge() : 
	v1_order(-1),v2_order(-1),mapXCoord(-1),mapYCoord(-1){};

Face::Face(int v1o,int v2o,int v3o,int v4o,int e1o,int e2o,int e3o,int e4o,int mx,int my):
	mapXCoord(mx),mapYCoord(my){
		vector< int >tmpvec (4,0);
		tmpvec[0]=v1o;
		tmpvec[1]=v2o;
		tmpvec[2]=v3o;
		tmpvec[3]=v4o;
		sort(tmpvec.begin(),tmpvec.end());
		v1_order=tmpvec[0];
		v2_order=tmpvec[1];
		v3_order=tmpvec[2];
		v4_order=tmpvec[3];

		vector< int >tmpEdgevec (4,0);
		tmpEdgevec[0]=e1o;
		tmpEdgevec[1]=e2o;
		tmpEdgevec[2]=e3o;
		tmpEdgevec[3]=e4o;
		sort(tmpEdgevec.begin(),tmpEdgevec.end());
		e1_order=tmpEdgevec[0];
		e2_order=tmpEdgevec[1];
		e3_order=tmpEdgevec[2];
		e4_order=tmpEdgevec[3];
	};
Face::Face() : 
	v1_order(-1),v2_order(-1),v3_order(-1),v4_order(-1),e1_order(-1),e2_order(-1),e3_order(-1),e4_order(-1),mapXCoord(-1),mapYCoord(-1){};

bool Vertex::operator<(const Vertex &rhs) const{
    return (this->val < rhs.val);
  };

bool Edge::operator<(const Edge &rhs) const{ 
	if(this->v2_order!=rhs.v2_order)
		return this->v2_order<rhs.v2_order;
	if(this->v1_order!=rhs.v1_order)
		return this->v1_order<rhs.v1_order;
};

bool Face::operator<(const Face &rhs) const{ 
	if(this->e4_order!=rhs.e4_order)
		return this->e4_order<rhs.e4_order;
	if(this->e3_order!=rhs.e3_order)
		return this->e3_order<rhs.e3_order;
	if(this->e2_order!=rhs.e2_order)
		return this->e2_order<rhs.e2_order;
	if(this->e1_order!=rhs.e1_order)
		return this->e1_order<rhs.e1_order;
};

void CellMap::setVertOrder(int rid, int cid, int vorder){
		
		MY_ASSERT(( (rid >=0)&&(rid < mapNRow)&&(cid >= 0)&&(cid < mapNCol) ), "%s/n", "ERROR");
		MY_ASSERT(( cellType[rid][cid] == VERTEX ), "%s/n", "ERROR");
		
		MY_ASSERT((cellOrder[rid][cid] == -1), "%s/n", "ERROR"); //this vert has not been specified
		
		cellOrder[rid][cid] = vorder;

		vector< vector < int > > neighborOrder(5, vector< int >(5,-1));

		int i,j;
		
		// get the neighboring orders
		for (i=rid-2;i<=rid+2;i++){
			if ((i<0)||(i>=mapNRow)) continue;
			for(j=cid-2;j<=cid+2;j++){
				if ((j<0)||(j>=mapNCol)) continue;
				neighborOrder[i+2-rid][j+2-cid]=cellOrder[i][j];
			}
		}
		
		// update the neighboring orders
// 		int ue,de,le,re,ult,urt,dlt,drt;
// 		int uv,dv,lv,rv,ulv,urv,dlv,drv;
		int & uv = neighborOrder[0][2];
		int & dv = neighborOrder[4][2];
		int & lv = neighborOrder[2][0];
		int & rv = neighborOrder[2][4];
		int & ulv = neighborOrder[0][0];
		int & urv = neighborOrder[0][4];
		int & dlv = neighborOrder[4][0];
		int & drv = neighborOrder[4][4];

		int & ue = neighborOrder[1][2];
		int & de = neighborOrder[3][2];
		int & le = neighborOrder[2][1];
		int & re = neighborOrder[2][3];
		int & ult = neighborOrder[1][1];
		int & urt = neighborOrder[1][3];
		int & dlt = neighborOrder[3][1];
		int & drt = neighborOrder[3][3];

		if (uv>=0){
			ue = currEOrder;
			currEOrder++;
		}
		if (dv>=0){
			de = currEOrder;
			currEOrder++;
		}
		if (lv>=0){
			le = currEOrder;
			currEOrder++;
		}
		if (rv>=0){
			re = currEOrder;
			currEOrder++;
		}
		if ((uv>=0)&&(ulv>=0)&&(lv>=0)){
			ult = currTOrder;
			currTOrder++;
		}
		if ((uv>=0)&&(urv>=0)&&(rv>=0)){
			urt = currTOrder;
			currTOrder++;
		}
		if ((dv>=0)&&(dlv>=0)&&(lv>=0)){
			dlt = currTOrder;
			currTOrder++;
		}
		if ((dv>=0)&&(drv>=0)&&(rv>=0)){
			drt = currTOrder;
			currTOrder++;
		}

		// copy the neighboring orders back
		for (i=rid-2;i<=rid+2;i++){
			if ((i<0)||(i>=mapNRow)) continue;
			for(j=cid-2;j<=cid+2;j++){
				if ((j<0)||(j>=mapNCol)) continue;
				if (cellOrder[i][j]!=neighborOrder[i+2-rid][j+2-cid]){
					MY_ASSERT(( cellOrder[i][j]==-1 ), "%s/n", "ERROR");
					MY_ASSERT(( cellType[i][j]!=VERTEX ), "%s/n", "ERROR");
					cellOrder[i][j]=neighborOrder[i+2-rid][j+2-cid];
				}
			}
		}
		
	};


CellMap::CellMap(vector< Vertex > * vL, vector< Edge > * eL, vector< Face > * tL, int nrow, int ncol){

		int i,j,idx;

		vList=vL;
		eList=eL;
		fList=tL;
		MY_ASSERT((eList->size()==0), "%s/n", "ERROR");
		MY_ASSERT((fList->size()==0), "%s/n", "ERROR");
		
		vertNum = vList->size();
		edgeNum = nrow *(ncol - 1) + ncol*(nrow - 1);
		faceNum = (ncol - 1) * (nrow - 1);

		mapNRow = 2*(nrow)-1;
		mapNCol = 2*(ncol)-1;
		currEOrder=0;
		currTOrder=0;

//		int i, j;

		cellOrder.assign(mapNRow, vector< int >(mapNCol, -1));
		edgePersType.assign(mapNRow, vector< EdgePersTypeEnum >(mapNCol, EP_UNDEFINED));

		// create cellType, row by row
		vector< CellTypeEnum > 	zeroRow( mapNCol, VERTEX );
		for (i = 0; i < mapNCol; i++)
			if ( i % 2 == 1 ) zeroRow[i] = EDGEHORI;
		vector< CellTypeEnum > 	firstRow( mapNCol, EDGEVERT );
		for (i = 0; i < mapNCol; i++)
			if ( i % 2 == 1 ) firstRow[i] = FACE;
		for ( i = 0; i < mapNRow; i++)
			if (i % 2 == 0)
				cellType.push_back(zeroRow);
			else
				cellType.push_back(firstRow);

		// flood 
		for( i = 0; i<vertNum; i++)
			setVertOrder((* vList)[i].xidx*2 ,(* vList)[i].yidx*2, i);
		MY_ASSERT((currEOrder == edgeNum), "%s/n", "ERROR");
		MY_ASSERT((currTOrder == faceNum), "%s/n", "ERROR");
		
		eList->assign(edgeNum,Edge());
		fList->assign(faceNum,Face());

//		int idx;
		// build elist and tlist
		for (i=0;i<mapNRow;i++)
			for (j=0;j<mapNCol;j++){
				idx = cellOrder[i][j];
				MY_ASSERT((idx>=0), "%s/n", "ERROR");
				if (cellType[i][j]==EDGEHORI){
					MY_ASSERT((idx<edgeNum), "%s/n", "ERROR");
					(* eList)[idx]=Edge(cellOrder[i][j-1],cellOrder[i][j+1],i,j);
				}else if(cellType[i][j]==EDGEVERT){
					MY_ASSERT((idx<edgeNum), "%s/n", "ERROR");
					(* eList)[idx]=Edge(cellOrder[i-1][j],cellOrder[i+1][j],i,j);
				}else if(cellType[i][j]==FACE){
					MY_ASSERT((idx<faceNum), "%s/n", "ERROR");
					(* fList)[idx]=Face(cellOrder[i-1][j-1],cellOrder[i+1][j-1],cellOrder[i-1][j+1],cellOrder[i+1][j+1],
								cellOrder[i-1][j],cellOrder[i+1][j],cellOrder[i][j-1],cellOrder[i][j+1],
								i,j);
				}
			}

		//resort elist and triglist, so that they are alphabetically sorted
		sort(eList->begin(),eList->end());
		for(i=0;i<edgeNum;i++)
			cellOrder[(*eList)[i].mapXCoord][(*eList)[i].mapYCoord]=i;
		for (i=0;i<mapNRow;i++)
			for (j=0;j<mapNCol;j++){
				idx = cellOrder[i][j];
				MY_ASSERT((idx>=0), "%s/n", "ERROR");
				if(cellType[i][j]==FACE){
					MY_ASSERT((idx<faceNum), "%s/n", "ERROR");
					(* fList)[idx]=Face(cellOrder[i-1][j-1],cellOrder[i+1][j-1],cellOrder[i-1][j+1],cellOrder[i+1][j+1],
								cellOrder[i-1][j],cellOrder[i+1][j],cellOrder[i][j-1],cellOrder[i][j+1],
								i,j);
				}
			}
		sort(fList->begin(),fList->end());
		for(i=0;i<faceNum;i++)
			cellOrder[(*fList)[i].mapXCoord][(*fList)[i].mapYCoord]=i;

	};
	
void CellMap::buildBoundary2D(vector<vector < int > > * boundary_2D){
		int i, j, idx;
		for (i=0; i<faceNum; i++){
			(* boundary_2D)[i].push_back( (* fList)[i].e1_order );
			(* boundary_2D)[i].push_back( (* fList)[i].e2_order );
			(* boundary_2D)[i].push_back( (* fList)[i].e3_order );
			(* boundary_2D)[i].push_back( (* fList)[i].e4_order );
		}
	};
					
void CellMap::buildBoundary1D(vector<vector < int > > * boundary_1D){
		int i, j, idx;
		for (i=0; i<edgeNum; i++){
			(* boundary_1D)[i].push_back( (* eList)[i].v1_order );
			(* boundary_1D)[i].push_back( (* eList)[i].v2_order );
		}
	};

void CellMap::setEPersType( vector< int > * low_2D_e2t ){
		MY_ASSERT((low_2D_e2t->size() == edgeNum), "%s/n", "ERROR");
		int i,j,idx;
		for (i=0; i< mapNRow; i++)
			for (j=0; j< mapNCol; j++)
				if ((cellType[i][j]==EDGEVERT)||(cellType[i][j]==EDGEHORI)){
					idx=cellOrder[i][j];
					if ((* low_2D_e2t)[idx]!=-1)
						edgePersType[i][j] = CREATOR;
					else
						edgePersType[i][j] = DESTROYER;
				}
	};

