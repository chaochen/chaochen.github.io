/*****************************************************************************
*   Computing Persistence for 2D Image
*                        Version 2.0                                         
*    http://research.cs.rutgers.edu/~cc1092/
*    Written by Chao Chen (chao.chen.cchen@gmail.com)
*    Aug. 2014
*****************************************************************************/
#ifndef PERSISTENCE_H
#define PERSISTENCE_H

#include "utils.h"
#include "debugger.h"
#include "CubicalComplex.h"

#define MAX_PERS_PTS 1000	//maximum of numbers of persistence dots

//-----------------------------------------------------
//vertex-edge pair and persistence
//edge-trig pair and persistence
//-----------------------------------------------------
class VertEdgePair{
  public:
  int vbVertIdx;
  int edVertIdx;
  int edVertIdx2; // the other vertex of the death edge
  int edIdx; // the idx of the death edge
  float pers_val;
  float birth_val;
  float death_val;

  //initialize coordinates using the input vertices and persistence
  VertEdgePair(int vbi, int edi, float per, int edi2 = -1, int edidx = -1, float birth = -1.0, float death = -1.0);

  bool operator<(const VertEdgePair &rhs) const;
};

class EdgeFacePair{
  public:
  int ebVertIdx;  // birth vertex (max of birth edge)
  int fdVertIdx;  // death vertex (max of death face)
  float pers_val; 
  int ebIdx;      // birth edge
  int fdIdx;      // death face
  float birth_val;
  float death_val;
  
  //initialize coordinates using the input vertices and persistence
  EdgeFacePair( int ebi, int fdi, float per, int ebidx = -1, int fdidx = -1, float birth = -1.0, float death = -1.0) ; 

  bool operator<(const EdgeFacePair &rhs) const;
};


class Persistence{
	public: 
	vector< Vertex > * vList;
	vector< Edge > * eList;
	vector< Face > * fList;

 CellMap * myCM;

	myDoubleMatrix * phi;

	vector< VertEdgePair > * vePersList;
	vector< EdgeFacePair > * efPersList;
	int persPairSize;

 bool save_2D_generators;   // whether to save 2D generators
 vector<vector< int > > * boundary_2D_ptr; // if save 2D generators, this is a pointer to the reduced 2D boundary matrix

 bool use_smart_reduction_strategy; // whether to use a smart reduction strategy, a heuristic idea to get shorter generators
	public:

	Persistence( myDoubleMatrix * p, int use_srs = 0 ) : phi(p), persPairSize(3) {
		vList=new vector< Vertex >;
		eList=new vector< Edge >;
		fList=new vector< Face >;
		vePersList=new vector< VertEdgePair >;
		efPersList=new vector< EdgeFacePair >;
  save_2D_generators = false;
  boundary_2D_ptr = NULL;
  use_smart_reduction_strategy = (use_srs != 0);
	};

 void set_save_2D_generators(){
   save_2D_generators = true;
 };

	~Persistence(){
		delete vList;
		delete eList;
		delete fList;
		delete vePersList;
		delete efPersList;
  delete myCM;

  if(boundary_2D_ptr != NULL)
    delete boundary_2D_ptr;
	};

	void calcPers(const int, const int, const double, int, long double *);

	int getPersPairSize(){ return persPairSize; };

	int getVELSize(){ return vePersList->size(); };

	void outputVEL(double *);

 void outputVEL(fstream * fs_ptr, const int m,const int n, const double pers_thd );

	int getEFLSize(){ return efPersList->size(); };

	void outputEFL(double *);

 void outputEFL(fstream * fs_ptr, const int m,const int n, const double pers_thd, bool write_generators = false);

 pair<int, int> growComponent(int , Mat &, int );

 vector<pair<double, pair<Mat, Mat> > > outputZeroPersComponents(int, int );

 void CheckVals(int vid){
   double val = (* vList)[vid].val;
   double val2 = phi->data[(* vList)[vid].xidx][(* vList)[vid].yidx];
   assert(val == val2);
   cout << " vert id = " << vid << "; val = " << val << " or " << val2 << endl;
 }
};


#endif
