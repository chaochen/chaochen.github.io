/*****************************************************************************
*   Computing Persistence for 2D Image
*                        Version 2.0                                         
*    http://research.cs.rutgers.edu/~cc1092/
*    Written by Chao Chen (chao.chen.cchen@gmail.com)
*    Aug. 2014
*****************************************************************************/
// old code for detecting components with high persistence
// it also generate the component that a detected component is merged into

#include "debugger.h"
#include "utils.h"
#include "CubicalComplex.h"
#include "persistence.h"

using namespace cv;
using namespace std;

int main( int argc, char** argv )
{
  if( argc != 4)
  {
    cout <<" Usage: persImage image-name number-of-detections geom-constraint" << endl;
    return -1;
  }

  int num_output = atoi(argv[2]);
  if(num_output <= 0){
    cout <<" number-of-detections has to be a positive number "<< endl;
    return -1;
  }
  int geom_constraint = atoi(argv[3]);
  if(geom_constraint > 10){
    cout <<"WARNNING: geom_constraint is large, you might miss good detections "<< endl;
  }

  Mat image;
  image = imread(argv[1], CV_LOAD_IMAGE_COLOR);   // Read the file
  string infname = string(argv[1]);
  if(! image.data )                              // Check for invalid input
  {
    cout <<  "Could not open or find the image : " << argv[1] << endl ;
    return -1;
  }

  if( image.type() != CV_8UC3 ){
    cout << "Image type is not CV_8UC3" << endl;
    return -1;
  }

  Mat gray_image;
  cvtColor( image, gray_image, CV_RGB2GRAY );
  assert( gray_image.type() == CV_8UC1 );

//    namedWindow( "Display window", WINDOW_AUTOSIZE );// Create a window for display.
//    imshow( "Display window", gray_image );                   // Show our gray_image inside it.
//  
//    waitKey(0);                                          // Wait for a keystroke in the window

  myDoubleMatrix * phi;
	 phi=new myDoubleMatrix(gray_image.rows, gray_image.cols);
	 phi->inputFromMat(gray_image);

//  Mat gi2;
//  phi->outputToMat(gi2);
//  Utils::testShowImage( gi2 );

  int maxdegree = 3;
	 long double * degreep=new long double [maxdegree];
  double pers_thd = 0.01;

	Persistence pers(phi);
	pers.calcPers(phi->nrow, phi->ncol, pers_thd, maxdegree,degreep);
  
 vector<pair<double, pair<Mat, Mat> > > detected_masks = pers.outputZeroPersComponents(num_output, geom_constraint);

 cout << " number of detected = " << detected_masks.size() << endl;

 string outfname = infname;
 int pos = outfname.size()-4;
 outfname = outfname.insert(pos, "_detection_");
 pos = outfname.size()-4;
 for(int i = 0; i < detected_masks.size(); ++i){
    string tmp_ofname_p1 = outfname;
    tmp_ofname_p1.insert(pos, Utils::Int2Str(i+1)+string("_p1"));

    string tmp_ofname_p2 = outfname;
    tmp_ofname_p2.insert(pos, Utils::Int2Str(i+1)+string("_p2"));

    cout << " detection id = " << i+1 << " persistence = " << detected_masks[i].first << " fname = " << tmp_ofname_p1 << " and " << tmp_ofname_p2 << endl;
    Mat tmp_img_p1;
    image.copyTo(tmp_img_p1, detected_masks[i].second.first);
    imwrite( tmp_ofname_p1.c_str(), tmp_img_p1 );

    Mat tmp_img_p2;
    image.copyTo(tmp_img_p2, detected_masks[i].second.second);
    imwrite( tmp_ofname_p2.c_str(), tmp_img_p2 );
 }

	 delete [] degreep;	
	 delete phi;
  return 0;
}
